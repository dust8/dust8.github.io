Hi there! Some notes of use:

This sets your mouse to linear (zero) acceleration and keeps it there. You need to adjust your sensitivity using the driver panel for your mouse, or adjust your mouse's DPI somehow. YOU CAN NOT USE THE SYSTEM PREFERENCES to change your mouse speed. That will always reset everything.

A sample installation for a Razer Death Adder:
- Set Razer panel to 1800dpi, sensitivity on 5
- Install Mouse Fixer
- Restart Computer
- Enjoy! This will be the exact same sensitivity as in windows.


I maybe adding a configuration tool to allow sensitivity changes on any mouse. For now I have only tested with Razer devices. 

I do not know if this works with USB Overdrive installed. If you have it installed, let me know if it does anything. Please try it with USB Overdrive off as well. Thank you.

To uninstall, remove /Applications/MouseFixers and /Library/LaunchAgainst/com.bumblebee.mousefixer.plist then restart.


If this works for you, please donate! paypal @ audiolabs@gmail.com